### The Floating Fish PWA (Progressive Web App)

To generate new css file based on tailwind css, run this command:
```
npx tailwindcss-cli@latest build -o css/tailwind.css
```
