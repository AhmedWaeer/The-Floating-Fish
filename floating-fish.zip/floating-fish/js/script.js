const styles = [
    {
        img: 'https://www.pinterest.com/pin/5136987063769128/',
        styles: ['bohemian']
    },
    {
        img: 'https://www.pinterest.com/pin/454089574922886416/',
        styles: ['bohemian', 'modern']
    },
    {
        img: 'https://www.pinterest.com/pin/5136987063769128/',
        styles: ['classic']
    },
]


